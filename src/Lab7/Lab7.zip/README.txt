All java and png files in the same package(folder) "Lab7"
