All files in the same package(folder) "Homework3"

Main.java contains main function