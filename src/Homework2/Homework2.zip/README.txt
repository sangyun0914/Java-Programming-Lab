Main.java and Fraction.java in the same package(folder) "Homework2"
(as in same folder, does not need import)