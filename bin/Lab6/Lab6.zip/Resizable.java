package Lab6;

public interface Resizable {

    public void resize(double ratio);

    public int compareTo(TwoDimensionalShape shape);

}
