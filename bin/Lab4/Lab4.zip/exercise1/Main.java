package Lab4.exercise1;

public class Main {
    public static void main(String[] args) {
        DeckOfCards deck = new DeckOfCards();
        deck.shuffle();
        deck.deal();
    }
}
