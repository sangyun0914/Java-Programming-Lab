package 'Lab4.exercise1' includes the following three java files:
	- Main.java
	- Card.java
	- DeckOfCards.java