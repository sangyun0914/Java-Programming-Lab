package 'Lab4.exercise2' contains following three java files:
	- Main.java
	- Weapon.java
	- Character.java